create function pop()
    returns TABLE(pc integer, pd integer)
    language plpgsql
as
$$
declare
    --variable declaration
begin
    return query
        select popcap, popcap from districts;
end;
$$;

alter function pop() owner to postgres;


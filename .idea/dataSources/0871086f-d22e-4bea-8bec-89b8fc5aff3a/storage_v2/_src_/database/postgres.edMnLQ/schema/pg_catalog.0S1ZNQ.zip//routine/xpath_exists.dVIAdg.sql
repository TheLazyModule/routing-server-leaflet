create function xpath_exists(text, xml) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language sql
RETURN xpath_exists($1, $2, '{}'::text[]);

comment on function xpath_exists(text, xml) is 'test XML value against XPath expression';

alter function xpath_exists(text, xml) owner to postgres;


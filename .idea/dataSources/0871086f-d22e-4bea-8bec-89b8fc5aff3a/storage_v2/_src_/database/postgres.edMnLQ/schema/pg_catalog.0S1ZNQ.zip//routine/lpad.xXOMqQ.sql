create function lpad(text, integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language sql
RETURN lpad($1, $2, ' '::text);

comment on function lpad(text, integer) is 'left-pad string to length';

alter function lpad(text, integer) owner to postgres;


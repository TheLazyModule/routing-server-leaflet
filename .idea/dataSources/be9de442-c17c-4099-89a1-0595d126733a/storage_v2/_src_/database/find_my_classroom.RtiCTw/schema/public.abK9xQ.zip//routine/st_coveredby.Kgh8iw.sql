create function st_coveredby(text, text) returns boolean
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_CoveredBy($1::public.geometry, $2::public.geometry);  $$;

alter function st_coveredby(text, text) owner to rdsadmin;


create function st_linelocatepoint(text, text) returns double precision
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_LineLocatePoint($1::public.geometry, $2::public.geometry);  $$;

alter function st_linelocatepoint(text, text) owner to rdsadmin;


create function st_symmetricdifference(geom1 geometry, geom2 geometry) returns geometry
    language sql
as
$$SELECT ST_SymDifference(geom1, geom2, -1.0);$$;

alter function st_symmetricdifference(geometry, geometry) owner to root;


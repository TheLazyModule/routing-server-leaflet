create function st_length(text) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT public.ST_Length($1::public.geometry);  $$;

alter function st_length(text) owner to supabase_admin;

grant execute on function st_length(text) to postgres;

grant execute on function st_length(text) to anon;

grant execute on function st_length(text) to authenticated;

grant execute on function st_length(text) to service_role;


create function st_intersection(text, text) returns geometry
    immutable
    strict
    parallel safe
    cost 10000
    language sql
as
$$ SELECT public.ST_Intersection($1::public.geometry, $2::public.geometry);  $$;

alter function st_intersection(text, text) owner to supabase_admin;

grant execute on function st_intersection(text, text) to postgres;

grant execute on function st_intersection(text, text) to anon;

grant execute on function st_intersection(text, text) to authenticated;

grant execute on function st_intersection(text, text) to service_role;


create function st_dwithin(text, text, double precision) returns boolean
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_DWithin($1::public.geometry, $2::public.geometry, $3);  $$;

alter function st_dwithin(text, text, double precision) owner to supabase_admin;

grant execute on function st_dwithin(text, text, double precision) to postgres;

grant execute on function st_dwithin(text, text, double precision) to anon;

grant execute on function st_dwithin(text, text, double precision) to authenticated;

grant execute on function st_dwithin(text, text, double precision) to service_role;


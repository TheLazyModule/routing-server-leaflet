create function st_intersects(text, text) returns boolean
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_Intersects($1::public.geometry, $2::public.geometry);  $$;

alter function st_intersects(text, text) owner to supabase_admin;

grant execute on function st_intersects(text, text) to postgres;

grant execute on function st_intersects(text, text) to anon;

grant execute on function st_intersects(text, text) to authenticated;

grant execute on function st_intersects(text, text) to service_role;


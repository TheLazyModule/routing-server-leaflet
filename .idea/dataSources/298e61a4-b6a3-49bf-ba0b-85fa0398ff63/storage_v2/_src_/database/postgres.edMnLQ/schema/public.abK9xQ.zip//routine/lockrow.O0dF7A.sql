create function lockrow(text, text, text) returns integer
    strict
    language sql
as
$$ SELECT LockRow(current_schema(), $1, $2, $3, now()::timestamp+'1:00'); $$;

comment on function lockrow(text, text, text) is 'args: a_table_name, a_row_key, an_auth_token - Sets lock/authorization for a row in a table.';

alter function lockrow(text, text, text) owner to supabase_admin;

grant execute on function lockrow(text, text, text) to postgres;

grant execute on function lockrow(text, text, text) to anon;

grant execute on function lockrow(text, text, text) to authenticated;

grant execute on function lockrow(text, text, text) to service_role;


create function st_polygonfromwkb(bytea) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$
	SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1)) = 'POLYGON'
	THEN public.ST_GeomFromWKB($1)
	ELSE NULL END
	$$;

alter function st_polygonfromwkb(bytea) owner to supabase_admin;

grant execute on function st_polygonfromwkb(bytea) to postgres;

grant execute on function st_polygonfromwkb(bytea) to anon;

grant execute on function st_polygonfromwkb(bytea) to authenticated;

grant execute on function st_polygonfromwkb(bytea) to service_role;


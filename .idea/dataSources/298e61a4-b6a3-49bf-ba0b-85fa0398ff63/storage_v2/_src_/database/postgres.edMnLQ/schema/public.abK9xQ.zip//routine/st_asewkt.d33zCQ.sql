create function st_asewkt(text) returns text
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$ SELECT public.ST_AsEWKT($1::public.geometry);  $$;

alter function st_asewkt(text) owner to supabase_admin;

grant execute on function st_asewkt(text) to postgres;

grant execute on function st_asewkt(text) to anon;

grant execute on function st_asewkt(text) to authenticated;

grant execute on function st_asewkt(text) to service_role;


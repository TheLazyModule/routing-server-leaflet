create function _st_distanceuncached(geography, geography, boolean) returns double precision
    immutable
    strict
    language sql
as
$$SELECT public._ST_DistanceUnCached($1, $2, 0.0, $3)$$;

alter function _st_distanceuncached(geography, geography, boolean) owner to supabase_admin;

grant execute on function _st_distanceuncached(geography, geography, boolean) to postgres;

grant execute on function _st_distanceuncached(geography, geography, boolean) to anon;

grant execute on function _st_distanceuncached(geography, geography, boolean) to authenticated;

grant execute on function _st_distanceuncached(geography, geography, boolean) to service_role;


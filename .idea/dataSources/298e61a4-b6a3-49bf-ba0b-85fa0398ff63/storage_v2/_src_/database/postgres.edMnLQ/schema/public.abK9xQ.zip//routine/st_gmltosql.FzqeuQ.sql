create function st_gmltosql(text) returns geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$SELECT public._ST_GeomFromGML($1, 0)$$;

alter function st_gmltosql(text) owner to supabase_admin;

grant execute on function st_gmltosql(text) to postgres;

grant execute on function st_gmltosql(text) to anon;

grant execute on function st_gmltosql(text) to authenticated;

grant execute on function st_gmltosql(text) to service_role;


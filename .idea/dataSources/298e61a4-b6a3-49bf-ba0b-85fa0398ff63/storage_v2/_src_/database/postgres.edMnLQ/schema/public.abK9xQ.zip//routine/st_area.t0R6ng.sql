create function st_area(text) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT public.ST_Area($1::public.geometry);  $$;

alter function st_area(text) owner to supabase_admin;

grant execute on function st_area(text) to postgres;

grant execute on function st_area(text) to anon;

grant execute on function st_area(text) to authenticated;

grant execute on function st_area(text) to service_role;


create function overlaps_geog(geography, gidx) returns boolean
    immutable
    strict
    language sql
as
$$SELECT $2 OPERATOR(public.&&) $1;$$;

alter function overlaps_geog(geography, gidx) owner to supabase_admin;

grant execute on function overlaps_geog(geography, gidx) to postgres;

grant execute on function overlaps_geog(geography, gidx) to anon;

grant execute on function overlaps_geog(geography, gidx) to authenticated;

grant execute on function overlaps_geog(geography, gidx) to service_role;


create function st_asgeojson(text) returns text
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$ SELECT public.ST_AsGeoJson($1::public.geometry, 9, 0);  $$;

alter function st_asgeojson(text) owner to supabase_admin;

grant execute on function st_asgeojson(text) to postgres;

grant execute on function st_asgeojson(text) to anon;

grant execute on function st_asgeojson(text) to authenticated;

grant execute on function st_asgeojson(text) to service_role;


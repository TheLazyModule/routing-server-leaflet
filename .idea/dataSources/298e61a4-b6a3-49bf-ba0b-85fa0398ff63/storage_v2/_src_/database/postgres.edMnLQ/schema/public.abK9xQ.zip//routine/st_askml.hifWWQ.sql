create function st_askml(text) returns text
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$ SELECT public.ST_AsKML($1::public.geometry, 15);  $$;

alter function st_askml(text) owner to supabase_admin;

grant execute on function st_askml(text) to postgres;

grant execute on function st_askml(text) to anon;

grant execute on function st_askml(text) to authenticated;

grant execute on function st_askml(text) to service_role;


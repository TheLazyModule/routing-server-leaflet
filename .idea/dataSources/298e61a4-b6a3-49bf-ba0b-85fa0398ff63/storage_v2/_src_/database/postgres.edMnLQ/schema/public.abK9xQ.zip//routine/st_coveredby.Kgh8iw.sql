create function st_coveredby(text, text) returns boolean
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_CoveredBy($1::public.geometry, $2::public.geometry);  $$;

alter function st_coveredby(text, text) owner to supabase_admin;

grant execute on function st_coveredby(text, text) to postgres;

grant execute on function st_coveredby(text, text) to anon;

grant execute on function st_coveredby(text, text) to authenticated;

grant execute on function st_coveredby(text, text) to service_role;


create function lockrow(text, text, text, text) returns integer
    strict
    language sql
as
$$ SELECT LockRow($1, $2, $3, $4, now()::timestamp+'1:00'); $$;

alter function lockrow(text, text, text, text) owner to supabase_admin;

grant execute on function lockrow(text, text, text, text) to postgres;

grant execute on function lockrow(text, text, text, text) to anon;

grant execute on function lockrow(text, text, text, text) to authenticated;

grant execute on function lockrow(text, text, text, text) to service_role;


create function st_polygonfromtext(text, integer) returns geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$SELECT public.ST_PolyFromText($1, $2)$$;

alter function st_polygonfromtext(text, integer) owner to supabase_admin;

grant execute on function st_polygonfromtext(text, integer) to postgres;

grant execute on function st_polygonfromtext(text, integer) to anon;

grant execute on function st_polygonfromtext(text, integer) to authenticated;

grant execute on function st_polygonfromtext(text, integer) to service_role;


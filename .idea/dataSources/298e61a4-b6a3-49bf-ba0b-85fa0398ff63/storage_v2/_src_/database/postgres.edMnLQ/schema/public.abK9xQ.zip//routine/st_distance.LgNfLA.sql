create function st_distance(text, text) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT public.ST_Distance($1::public.geometry, $2::public.geometry);  $$;

alter function st_distance(text, text) owner to supabase_admin;

grant execute on function st_distance(text, text) to postgres;

grant execute on function st_distance(text, text) to anon;

grant execute on function st_distance(text, text) to authenticated;

grant execute on function st_distance(text, text) to service_role;

